import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.StdOut;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Stack;

public class Solver {
    private final MinPQ<SolverStepNode> prioritizedSteps;
    private boolean isSolvable;
    private Stack<Board> solutionBoards = new Stack<>();
    private SolverStepNode finalNode;

    private class SolverStepNode {
        private int moves;
        private Board board;
        private SolverStepNode previousNode;

        public SolverStepNode(Board board, int moves, SolverStepNode previousNode) {
            this.moves = moves;
            this.board = board;
            this.previousNode = previousNode;
        }

        public int getMoves() {
            return moves;
        }

        public Board getBoard() {
            return board;
        }

        public SolverStepNode getPreviousNode() {
            return previousNode;
        }

        public int getPriority() {
            return board.manhattan() + moves;
        }
    }

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) {
            throw new IllegalArgumentException();
        }
        prioritizedSteps = new MinPQ<>(new SolverStepComparator());
        isSolvable = false;
        SolverStepNode solverStepNode = new SolverStepNode(initial, 0, null);
        prioritizedSteps.insert(solverStepNode);

        // construct a min priority queue
        SolverStepNode currentStepNode;
        while (!prioritizedSteps.min().getBoard().isGoal()) {
            currentStepNode = prioritizedSteps.delMin();
            // get the minimum node in min-heap
            for (Board board: currentStepNode.board.neighbors()) {
                if (solverStepNode.previousNode == null || !board.equals(solverStepNode.previousNode.board)) {
                    SolverStepNode neighbor = new SolverStepNode(board, solverStepNode.getMoves() + 1, currentStepNode);
                    prioritizedSteps.insert(neighbor);
                }
            }
        }

        currentStepNode = prioritizedSteps.delMin();
        isSolvable = currentStepNode.getBoard().isGoal();

        solutionBoards.add(currentStepNode.getBoard());
        while ((currentStepNode = currentStepNode.getPreviousNode()) != null) {
            solutionBoards.add(0, currentStepNode.getBoard());
        }
    }

    // is the initial board solvable
    public boolean isSolvable() {
        return isSolvable;
    }

    // min number of moves
    public int moves() {
        if (!isSolvable) return -1;
        else {
            return solutionBoards.size() - 1;
        }
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        Iterable<Board> iterable;
        if (isSolvable()) {
            iterable = new Iterable<Board>() {
                @Override
                public Iterator<Board> iterator() {
                    return new SolutionIterator();
                }
            };
        } else {
            iterable = null;
        }
        return iterable;
    }

    private static int numMoves(SolverStepNode node) {
        int moves = 0;
        SolverStepNode current = node;

        while (current.getPreviousNode() != null) {
            moves++;
            current = current.previousNode;
        }
        return moves;
    }

    private static class SolverStepComparator implements Comparator<SolverStepNode> {
        @Override
        public int compare(SolverStepNode step1, SolverStepNode step2) {
            return step1.getPriority() - step2.getPriority();
        }
    }

    private class SolutionIterator implements Iterator<Board> {
        private int index = 0;

        @Override
        public boolean hasNext() {
            return index < solutionBoards.size();
        }

        @Override
        public Board next() {
            return solutionBoards.get(index++);
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("It is not supported to remove a board from the solution.");
        }
    }

    public static void main(String[] args) {
        int[][] arr = {
                {0, 1, 3},
                {4, 2, 5},
                {7, 8, 6}
        };
        Board board = new Board(arr);
        var solver = new Solver(board);
        var solutions = solver.solution();
        System.out.println("Minimum number of moves: " + solver.moves());
        for (Board solution: solutions) {
            System.out.println("=======");
            StdOut.println(solution);
        }
    }

}
